#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define MAXSIZE 100
#define ERROR 0
#define OK 1

typedef int Status;
typedef int ElemType;
typedef struct
{
  ElemType * data;
  int top;
} SqStack;

typedef struct
{
  char * data;
  int top;
} Stack;

typedef enum
{
  lparen, rparen, plus, minus, multi, divide, mod, eos, operand
} precedence;

extern char expr[100];



char Pop1(Stack * S);
ElemType Pop(SqStack * S);
Status Push   (SqStack * S, ElemType e);
Status Init   (SqStack * S);
Status Push1   (Stack * S, char e);
Status Init1   (Stack * S);
void   PrintS (SqStack * S);
void   PrintS1(Stack * S);
precedence getToken(char * symbol, int  n);
void printToken(precedence token);
char getfromToken(precedence token);
int eval();
Stack  postfix(void);
