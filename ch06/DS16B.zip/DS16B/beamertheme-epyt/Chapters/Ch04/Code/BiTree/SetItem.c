#include"BiTree.h"

/* Set a node's value */
void SetItem(BTNode * pnode, ElemType item)
{
  pnode->data = item;
}
