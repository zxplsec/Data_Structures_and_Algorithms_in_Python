#include "Postfix.h"
char expr[100];

int main(void)
{
  int result;
  int i;
  Stack S;
  strcpy(expr, "(2+3)*5-6");
  
  S = postfix();
  PrintS1(&S);

  for(i = 1; i <= S.top; i++)
    expr[i-1] = S.data[i];
  expr[S.top] = '\0';
  
  puts(expr);
  
  result = eval();
  
  printf("%d\n", result);
  
  return 0;
}