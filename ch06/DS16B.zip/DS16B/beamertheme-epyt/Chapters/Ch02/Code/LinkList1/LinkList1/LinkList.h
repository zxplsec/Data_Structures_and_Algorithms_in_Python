#include <stdio.h>
#include <stdlib.h>

typedef int ElemType;

struct LNode
{
  ElemType data;
  struct LNode * next;
} LNode;

