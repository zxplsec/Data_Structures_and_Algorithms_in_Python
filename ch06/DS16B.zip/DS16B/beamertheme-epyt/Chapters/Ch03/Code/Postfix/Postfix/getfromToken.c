#include "Postfix.h"

char getfromToken(precedence token)
{
  switch (token)
  {
    case lparen:
      return('(');
    case rparen:
      return(')');
    case plus:
      return('+');
    case minus:
      return('-');
    case multi:
      return('*');
    case divide:
      return('/');
    case mod:
      return('%');
    case eos:
      return('\0');
    default:
      return('\0');
  }
}

