typedef struct CSNode {
  ElemType data;
  struct CSNode * firstchild, * rightsib;
} CSNode, * CSTree;
