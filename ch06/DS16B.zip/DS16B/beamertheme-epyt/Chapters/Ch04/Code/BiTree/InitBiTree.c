#include"BiTree.h"

/* Creat a new bitree */
BiTree InitBiTree(BTNode * root)
{
  BiTree tree = root;
  return tree;
}
