#include"BiTree.h"

/* Return a node's value */
ElemType GetItem(BTNode * pnode)
{
  return pnode->data;
}
