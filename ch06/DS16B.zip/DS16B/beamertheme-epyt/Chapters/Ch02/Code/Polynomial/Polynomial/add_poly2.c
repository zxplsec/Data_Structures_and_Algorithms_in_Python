#include "Polynomial.h"

Poly * add_poly(Poly * La, Poly * Lb)
{
  Poly * Lc, * pc, * pa, * pb, * ptr;
  float x;
  
  Lc = pc = La;
  pa = La->next; pb = Lb->next;
  
  while(pa != NULL && pb != NULL)
  {
    if (pa->expn < pb->expn)
    {
      pc->next = pa; pc = pa; pa = pa->next;
    }
    else if (pa->expn > pb->expn)
    {
      pc->next = pb; pc = pb; pb = pb->next;
    }
    else
    {
      x = pa->coef + pb->coef;
      if(fabs(x) <= 1.e-15)
      {
        ptr = pa; pa = pa->next; free(ptr);
        ptr = pb; pb = pb->next; free(ptr);
      }
      else
      {
        pc->next = pa; pa->coef = x;
        pc = pa; pa = pa->next;
        ptr = pb; pb = pb->next; free(pb);
      }
    }
  }
  
  if (pa==NULL)
    pc->next = pb;
  else
    pc->next = pa;
  
  return (Lc);
}
