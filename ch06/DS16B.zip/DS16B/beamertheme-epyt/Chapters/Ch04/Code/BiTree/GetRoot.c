#include"BiTree.h"

/* Return a BiTree's root */
BiTree GetRoot(BiTree tree)
{
  return tree;
}
