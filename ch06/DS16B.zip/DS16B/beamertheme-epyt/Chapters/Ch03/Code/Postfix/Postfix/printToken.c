#include "Postfix.h"

void printToken(precedence token)
{
  switch (token)
  {
    case lparen:
      printf("("); break;
    case rparen:
      printf(")"); break;
    case plus:
      printf("+"); break;
    case minus:
      printf("-"); break;
    case multi:
      printf("*"); break;
    case divide:
      printf("/"); break;
    case mod:
      printf("%%"); break;
    case eos:
      printf("\\0"); break;
    default:
      break;
  }
}

