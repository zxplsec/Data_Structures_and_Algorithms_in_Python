#include "Postfix.h"
char Pop1(Stack * S)
{
  char e;
  if (S->top == -1) printf("Empty and Cannot Pop!\n");
  e = S->data[S->top];
  S->top--;
  return e;
}
