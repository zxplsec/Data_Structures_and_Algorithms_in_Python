#include "Postfix.h"

int eval()
{
  precedence token;
  char symbol;
  int op1, op2;
  int n = 0;
  SqStack S;
  
  Init(&S);
  
  token = getToken(&symbol, n++);
  
  while (token != eos)
  {
    if (token == operand)
      Push(&S, symbol-'0');
    else
    {
      op2 = Pop(&S);
      op1 = Pop(&S);
      switch (token)
      {
        case plus:
          Push(&S, op1+op2);
          break;
        case minus:
          Push(&S, op1-op2);
          break;
        case multi:
          Push(&S, op1*op2);
          break;
        case divide:
          Push(&S, op1/op2);
          break;
        case mod:
          Push(&S, op1%op2);
          break;
        default:
          break;
      }
    }
    token = getToken(&symbol, n++);
  }
  return Pop(&S);
}