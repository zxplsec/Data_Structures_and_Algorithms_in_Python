#include "Postfix.h"

precedence getToken(char * symbol, int * n)
{
  *symbol = expr[(*n)++];
  switch (*symbol)
  {
    case '(':
      return lparen;
      break;
    case ')':
      return rparen;
      break;
    case '+':
      return plus;
      break;
    case '-':
      return minus;
      break;
    case '*':
      return multi;
      break;
    case '/':
      return divide;
      break;
    case '%':
      return mod;
      break;
    case '\0':
      return eos;
      break;
    default:
      return operand;
      break;
  }
}

