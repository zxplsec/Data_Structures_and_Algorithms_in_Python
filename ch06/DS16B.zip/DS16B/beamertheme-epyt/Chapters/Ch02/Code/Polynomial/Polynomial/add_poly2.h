//
//  add_poly2.h
//  Polynomial
//
//  Created by 黄晓敏 on 16/9/20.
//  Copyright © 2016年 Xiaoping Zhang. All rights reserved.
//

#ifndef add_poly2_h
#define add_poly2_h

#include <stdio.h>

#endif /* add_poly2_h */
