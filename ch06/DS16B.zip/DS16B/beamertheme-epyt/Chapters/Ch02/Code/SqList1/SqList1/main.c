//
//  main.c
//  SqList1
//
//  Created by 黄晓敏 on 16/9/13.
//  Copyright © 2016年 Xiaoping Zhang. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
  // insert code here...
  printf("Hello, World!\n");
    return 0;
}
