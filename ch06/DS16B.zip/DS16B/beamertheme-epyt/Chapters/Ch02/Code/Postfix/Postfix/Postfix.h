#include <stdio.h>

typedef enum
{
  lparen, rparen, plus, minus, multi, divide, mod, eos, operand
} precedence;

char expr[100];

precedence getToken(char * symbol, int * n);

