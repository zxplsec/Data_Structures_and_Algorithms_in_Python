#include "Postfix.h"

int eval(void)
{
  precedence token;
  char symbol;
  int op1, op2;
  int n = 0;
  int top = -1;
  token = getToken(&symbol, &n);
  
  while (token != eos)
  {
    if (token == operand)
      push(symbol-'0');
    else
    {
      op1 = pop();
      op2 = pop();
      switch (token) {
        case plus:
          push(op1+op2);
          break;
        case minus:
          push(op1-op2);
          break;
        case multi:
          push(op1*op2);
          break;
        case divide:
          push(op1/op2);
          break;
        case mod:
          push(op1%op2);
      }
    }
    token = getToken(&symbol, &n);
  }
  return pop();
}