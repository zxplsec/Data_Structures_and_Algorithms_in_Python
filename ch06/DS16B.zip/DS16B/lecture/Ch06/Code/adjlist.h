typedef char VertexType;
