#include "Postfix.h"
Status Init1(Stack *S)
{
  S->data = (char *) malloc(MAXSIZE * sizeof(char));
  if(!S->data)
  {
    printf("Malloc Failed!\n");
    return ERROR;
  }
  S->top = -1;
  return OK;
}
