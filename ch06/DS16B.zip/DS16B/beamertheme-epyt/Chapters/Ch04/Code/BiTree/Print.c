#include"BiTree.h"

void Print(ElemType item)
{
  printf("%d ", item);
}

