#include "Postfix.h"
ElemType Pop(SqStack * S)
{
  ElemType e;
  if (S->top == -1) printf("Empty and Cannot Pop!\n");
  e = S->data[S->top];
  S->top--;
  return e;
}
