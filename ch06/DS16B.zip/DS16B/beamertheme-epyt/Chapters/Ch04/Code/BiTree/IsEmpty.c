#include"BiTree.h"

/* Is a BiTree Empty? */
int IsEmpty(BiTree tree)
{
  if (tree == NULL)
    return 0;
  else
    return 1;
}

