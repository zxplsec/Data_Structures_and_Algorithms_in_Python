#include "Postfix.h"

precedence getToken(char * symbol, int n)
{
  *symbol = expr[n];
  switch (*symbol)
  {
    case '(':
      return lparen;
    case ')':
      return rparen;
    case '+':
      return plus;
    case '-':
      return minus;
    case '*':
      return multi;
    case '/':
      return divide;
    case '%':
      return mod;
    case '\0':
      return eos;
    default:
      return operand;
  }
}

