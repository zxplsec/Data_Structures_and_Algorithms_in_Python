#include "Postfix.h"

Stack  postfix(void)
{
  char symbol;
  int e;
  precedence token;
  int n = 0;
  int isp[] = { 0, 19, 12, 12, 13, 13, 13, 0};
  int icp[] = {20, 19, 12, 12, 13, 13, 13, 0};
  
  SqStack S1;
  Init(&S1);
  Push(&S1, eos);
  Stack S2;
  Init1(&S2);
  Push1(&S2, '\0');
  
  for (token = getToken(&symbol, n++);
       token != eos;
       token = getToken(&symbol, n++))
  {
    if (token == operand) Push1(&S2, symbol);
    else if (token == rparen)
    {
      while (S1.data[S1.top] != lparen)
      {
        e = Pop(&S1);
        Push1(&S2, getfromToken(e));
      }
      e = Pop(&S1);
    }
    else
    {
      while (isp[S1.data[S1.top]] >= icp[token])
      {
        e = Pop(&S1);
        Push1(&S2, getfromToken(e));
      }
      Push(&S1, token);
    }
  }
  
  while ((token = Pop(&S1)) != eos)
    Push1(&S2, getfromToken(token));
  
  return S2;
  
}