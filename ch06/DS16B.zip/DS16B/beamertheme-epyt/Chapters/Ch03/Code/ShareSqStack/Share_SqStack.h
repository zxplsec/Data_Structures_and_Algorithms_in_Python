typedef struct {
  ElemType data[MAXSIZE];
  int top1;
  int top2;
} Share_SqStack;
