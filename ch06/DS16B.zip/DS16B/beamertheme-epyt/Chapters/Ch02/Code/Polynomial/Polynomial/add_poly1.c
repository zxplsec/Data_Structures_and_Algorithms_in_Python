#include "Polynomial.h"

void add_poly(Poly * La, Poly * Lb)
{
  Poly * Lc, * pc, * pa, * pb, * p;
  float x;
  
  Lc = pc = (Poly *) malloc(sizeof(Poly));
  pa = La->next;
  pb = Lb->next;
  
  while(pa != NULL && pb != NULL)
  {
    if (pa->expn < pb->expn)
    {
      p=(Poly *) malloc(sizeof(Poly));
      p->coef = pa->coef; p->expn = pa->expn;
      p->next = NULL;
      pc->next = p; pc = p; pa = pa->next;
    }
    else if (pa->expn > pb->expn)
    {
      p=(Poly *) malloc(sizeof(Poly));
      p->coef = pb->coef; p->expn = pb->expn;
      p->next = NULL;
      pc->next = p; pc = p; pb = pb->next;
    }
    if (pa->expn == pb->expn)
    {
      x = pa->coef + pb->coef;
      if(fabs(x) <= 1.e-15)
      {
        pa = pa->next;  pb = pb->next;
      }
      else
      {
        p=(Poly *) malloc(sizeof(Poly));
        p->coef = x; p->expn = pb->expn;
        p->next = NULL;
        pc->next = p; pc = p;
        pa = pa->next; pb = pb->next;
      }
    }
  }
  
  if (pb != NULL)
    while (pb != NULL)
    {
      p = (Poly *) malloc(sizeof(Poly));
      p->coef = pb->coef; p->expn = pb->expn;
      p->next = NULL;
      pc->next = p; pc = p; pb = pb->next;
    }
  
  if (pa != NULL)
    while (pa != NULL) {
      p = (Poly *) malloc(sizeof(Poly));
      p->coef = pa->coef; p->expn = pa->expn;
      p->next = NULL;
      pc->next = p; pc = p; pa = pa->next;
    }
}

